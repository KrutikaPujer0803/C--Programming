#include<stdio.h>
int main()
{
int matrix[2][3]={
{1,2,3},
{4,5,6}
};
   printf("matrix elements");
