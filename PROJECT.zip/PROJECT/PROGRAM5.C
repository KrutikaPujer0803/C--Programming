#include<stdio.h>
int main()
{
int i,num,rev=0;
printf("enter a number");
scanf("%d",&num);
for(;num!=0; num/=10){
rev=rev*10+ num%10;
}
printf("reversed number=%d",rev);
return 0;
}


