#include<stdio.h>
int main()
{
  FILE*file;
  char data[500];
  printf("enter a line to append\n");
  gets(data);

  file=fopen("output.txt","a");
  if(file==NULL){
       printf("error opening file\n");
       return 1;
       }
       fprintf(file,"%s",data);
       fclose(file);
       printf("line append successfully\n");
       return 0;
       }