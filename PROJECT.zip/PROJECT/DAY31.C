
#include<stdio.h>
int main()
{
int i;
int arr[10]={5,7,3,8,2,11};
    for(i=0;i<10;i++){
      printf("%d\n",arr[i]);
      }
      return 0;
}

