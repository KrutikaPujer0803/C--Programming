//using 1D array

#include<stdio.h>
int main()
{
int i;
int arr[4],sum=0;
printf("enter a number");
      for(i=0;i<4;i++){
      scanf("%d",&arr[i]);
      sum+=arr[i];
      }
      printf("sum of elements: %d\n",sum);
      return 0;
 }

