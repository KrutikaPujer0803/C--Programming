#include<stdio.h>
int main(){
char str[100]="i am krutika";
   int strlen(str);
   printf("enter the string length\n");
   return 0;
  }
