#include<stdio.h>
#include<string.h>
void main(){
	 char str1[100],str2[100];
	 printf("enter a first string");
	 gets(str1);
	 printf("enter second string");
	 gets(str2);
	 strcat(str1,str2);
	 printf("concatinated string:%s\n",str1);
	 }