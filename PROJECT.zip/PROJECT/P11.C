#include<stdio.h>
int main(){
 int num=10,*ptr;
 ptr=&num;
 *ptr=20;
 printf("update the value of num %d\n",num);
 return 0;
 }