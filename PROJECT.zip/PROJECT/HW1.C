#include<stdio.h>
int main(){
int a,b;
printf("enter the number");
scanf("%d",&a);
  if(a%2==0){
    printf("the number=%d is even number");
    }
    else{
    printf("the number=%d is odd number");
    }
    return 0;
    }