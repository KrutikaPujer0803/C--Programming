//comparision identical or not



#include<stdio.h>
#include<string.h>
void main(){
   char str1[100],str2[100];
   printf("enter first string");
   gets(str1);

   printf("enter second string");
   gets(str2);

   if(strcmp(str1,str2)==0){
       printf("strings are identical.\n");
   }else{
	printf("strings are not identical.\n");
	}
   }