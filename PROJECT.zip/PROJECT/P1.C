#include<stdio.h>

void main(){
 char str[100];
   printf("enter a string");
   gets(str);
   printf("you entered string %s\n",str);


   }

