#include<stdio.h>

// function decliration(prototype)
void greet();

int main()
{
     greet();//function call
     return 0;
}

//function defenation
void greet()
{
      printf("hello,i'm Krutika");
      }













