#include<stdio.h>
int main()
{
int a,b,c;
printf("enter three numbers");
scanf("%d%d%d",&a,&b,&c);
if(a>b&&b>c)
{printf("%d a is greter number,\n",a,b);
}
else
{
print("%d is greater number,\n",c);
}
return 0;
}
