#include<stdio.h>
int square(int n);
int main(){
int num,result;
printf("enter a number");
scanf("%d",&num);
result=square(num);
printf("square of %d is %d\n",num,result);
return 0;
}
int square(int n){
return n*n;
}